<?php include ('template/o_nav.php');?>
<h1>Dashboard</h1>

<?php include ('template/o_footer.php');?>