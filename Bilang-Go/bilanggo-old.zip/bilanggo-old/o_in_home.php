<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: officer.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OFFICER</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/inmate.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/o_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Inmate List</h2>    
            <a href="o_in_create.php"><button class="newbtn">Create New</button></a>  
             </div>         
            
           <div class="s_hold">
                <form action="o_in_search.php" method="get">
                <input type="text" name="search_term" id="search_term" placeholder="Search" required>
                <button type="submit" value="Search" id="sbtn"><i class="fas fa-search"></i></button>   
                </form>
            </div>
                  
            <table class="prison_table">
                         <thead>
                            <tr>
                                <th>Date Created</th>
                                <th>Prison Code</th>
                                <th>Full Name</th>
                                <th>Gender</th>
                                <th>Action</th>
                            </tr>
                         </thead>
                         <tbody>
                         <?php 
                        $statement = $pdo->prepare("SELECT * FROM inmate 
                        LEFT JOIN cell ON inmate.cellname = cell.cell_id
                        LEFT JOIN prison ON inmate.prisonname = prison.prison_id");
                        $statement->execute();
                        $result = $statement->fetchAll();

                        foreach ($result as $row) {
                            $inmate_id = $row['inmate_id'];
                            $date_create = $row['date_create'];
                            $prison_code = $row['prison_code'];
                            $lastname = $row['lastname'];
                            $firstname = $row['firstname'];
                            $middlename = $row['middlename'];
                            $gender = $row['gender'];
                            $prison_name = $row['prison_name'];
                        ?>
                             <tr>
                                <td id="m<?= $date_create ?>"><?= $date_create ?></td>
                                <td id="m<?= $prison_code ?>"><?= $prison_code ?></td>
                                <td id="m<?= $lastname ?><?= $firstname ?><?= $middlename ?>"><?= $lastname ?>, <?= $firstname ?> <?= $middlename ?></td> 
                                <td id="m<?= $gender ?>"><?= $gender ?></td> 
                                <td>
                                    <a href="o_in_update.php?id=<?=$inmate_id; ?>"><i class='fas fa-edit'></i></a>
                                    <a href="o_in_view.php?id=<?=$inmate_id; ?>"><i class='far fa-eye'></i></a>&ensp;
                                    <form action="cud.php" method="POST">
                                        <button type="submit" name="delete-inmate" value="<?=$inmate_id; ?>"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                                    <?php
                                }
                            ?>
                         </tbody>
                    </table>

        </div>

    </main>
        <div class="header_hold">
    <?php include ('template/o_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/o_footer.php');?>
    </div>
    
</body>
</html>