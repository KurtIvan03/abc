<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: jailer.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JAILER</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/visitorpage.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/j_nav.php');?>
    </div>
    
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Visitor List</h2>    
            </div>
            <div class="s_hold">
                <form action="j_vi_search.php" method="get">
                <input type="text" name="search_term" id="search_term" placeholder="Search" required>
                <button type="submit" value="Search" id="sbtn"><i class="fas fa-search"></i></button>   
                </form>
            </div>
            <table class="prison_table">
                         <thead>
                            <tr>
                                <th>Date Created</th>
                                <th>Prison Code</th>
                                <th>Full Name</th>
                                <th>Relationship</th>
                                <th>Contact</th>
                                <th>Action</th>
                            </tr>
                         </thead>
                         <tbody>
                            <?php

                            $query = "SELECT * FROM visitor";
                            $statement = $pdo->prepare($query);
                            $statement->execute();
                            $result = $statement->fetchAll(PDO::FETCH_OBJ);
                            if($result){
                                foreach($result as $row ){
                                ?>
                            <tr>
                                <td><?= $row->vi_date_create;?></td>
                                <td><?= $row->inmateid ;?></td>
                                <td><?= $row->lastname , ', ', $row->firstname ,' ', $row->middlename ;?></td>
                                <td><?= $row->relationship;?></td>
                                <td><?= $row->contact;?></td>
                                <td>
                                    
                                <a href="j_vi_view.php?id=<?=$row->id; ?>"><i class='far fa-eye'></i></a>
                                    <form action="cud.php" method="POST">
                                        <button type="submit" name="delete-avi-btn" value="<?=$row->id; ?>"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                                    <?php
                                }
                            }else{
                                ?><?php                
                            } 
                            ?>
                         </tbody>
                    </table>

        </div>

    </main>
    <div class="header_hold">
    <?php include ('template/j_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/j_footer.php');?>
    </div>
</body>
</html>