<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/account.css">
    <script>
        function openForm(formName) {
        var i;
        var x = document.getElementsByClassName("form");
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";  
        }
        document.getElementById(formName).style.display = "block";  
        }
    
        function myFunction() {
        document.getElementById("myDropdown").classList.toggle("show");
        }
        window.onclick = function(event) {
        if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
            }
        }
        }
            function openReg() {
            document.getElementById("regForm").style.display = "block";
            }

            function closeReg() {
            document.getElementById("regForm").style.display = "none";
            }

            function openReg2() {
            document.getElementById("regForm2").style.display = "block";
            }

            function closeReg2() {
            document.getElementById("regForm2").style.display = "none";
            }
    
            function openReg3() {
            document.getElementById("regForm3").style.display = "block";
            }

            function closeReg3() {
            document.getElementById("regForm3").style.display = "none";
            }
    </script>
</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/a_nav.php');?>
    </div>
    <main class="output">
        <div class="account_hold">
            <div class="btn_hold">
                                    
                    <div class="btns">
                    <button class="button1" onclick="openForm('Admin')">Admin Account</button>
                    <button class="button2" onclick="openForm('Assistant')">Officer Account</button>
                    <button class="button3" onclick="openForm('User')">Jailer Account</button>
                    </div>
            </div>
                    <div id="Admin" class="w3-container form">
                        <div class="admin_header">
                            <h2> &emsp;ADMIN LIST</h2>
                    <button class="open-button" onclick="openReg()">Open Form</button>
                       <div class="form-popup" id="regForm">
                            <form action="cud.php" method="POST" class="form-container">
                                <br>
                                <h1>Admin Form</h1>
                                <br>
                            <div class="name_hold">
                            <label for="aln">Last Name:</label>
                            <input type="text" name="lastname" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="afn"> First Name:</label>
                            <input type="text" name="firstname" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="amn">Middle Name:</label>
                            <input type="text" name="middlename" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="aun">Username:</label>
                            <input type="text" name="uname" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="apw">Password:</label>
                            <input type="text" name="pword" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="aem">Email:</label>
                            <input type="text" name="email" id="m">
                            </div>
                            <br>
                <button type="submit" class="btn" name="save-admin">Save</button>
                <button type="button" class="btn cancel" onclick="closeReg()">Close</button>
            </form>
            </div>
                        </div>
                        <table class="admin_table">
                         <thead>
                            <tr>
                                <th>Date Create</th>
                                <th>Full Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                         </thead>
                         <tbody>
                            <?php

                            $query = "SELECT * FROM admin";
                            $statement = $pdo->prepare($query);
                            $statement->execute();
                            $result = $statement->fetchAll(PDO::FETCH_OBJ);
                            if($result){
                                foreach($result as $row ){
                                ?>
                                
                            <tr>
                                <td><?= $row->date_create;?></td>
                                <td><?= $row->lastname, ', ', $row->firstname, ' ', $row->middlename;?></td>
                                <td><?= $row->uname;?></td>
                                <td><?= $row->email;?></td>
                                <td>
                                    <a href="a_acc_a_update.php?id=<?=$row->id; ?>"><i class='fas fa-edit'></i></a>
                                <!--    <a href="avdetailss.php?id=<?=$row->id; ?>"><i class='far fa-eye'></i></a>-->
                                    <form action="cud.php" method="POST">
                                        <button type="submit" name="delete-admin" value="<?=$row->id; ?>"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                                    <?php
                                }
                            }else{
                                ?><?php                
                            } 
                            ?>
                         </tbody>
                    </table>
                </div>

                    <div id="Assistant" class="w3-container form" style="display:none">
                    <div class="assist_header">
                            <h2> &emsp;OFFICER LIST</h2>
                            <button class="open-button" onclick="openReg2()">Open Form</button>
                       <div class="form-popup" id="regForm2">
                            <form action="cud.php" method="POST" class="form-container">
                                <br>
                                <h1>Officer Form</h1>
                                <br>
                                <div class="name_hold">
                            <label for="cln">Last Name:</label>
                            <input type="text" name="lastname" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="cfn"> First Name:</label>
                            <input type="text" name="firstname" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="cmn">Middle Name:</label>
                            <input type="text" name="middlename" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="cun">Username:</label>
                            <input type="text" name="uname" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="cpw">Password:</label>
                            <input type="text" name="pword" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="cem">Email:</label>
                            <input type="text" name="email" id="m">
                            </div>
                            <br>
                <button type="submit" class="btn" name="save-officer">Save</button>
                <button type="button" class="btn cancel" onclick="closeReg2()">Close</button>
            </form>
            </div>
                        </div>
                        <table class="assist_table">
                         <thead>
                            <tr>
                                <th>Date Create</th>
                                <th>Full Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                         </thead>
                         <tbody>
                            <?php

                            $query = "SELECT * FROM officer";
                            $statement = $pdo->prepare($query);
                            $statement->execute();
                            $result = $statement->fetchAll(PDO::FETCH_OBJ);
                            if($result){
                                foreach($result as $row ){
                                ?>
                                
                            <tr>
                                <td><?= $row->date_create;?></td>
                                <td><?= $row->lastname, ', ' , $row->firstname, ' ', $row->middlename;?></td>
                                <td><?= $row->uname;?></td>
                                <td><?= $row->email;?></td>
                                <td>
                                    <a href="a_acc_o_update.php?id=<?=$row->id; ?>"><i class='fas fa-edit'></i></a>
                            <!--        <a href="aacview.php?id=<?=$row->id; ?>"><i class='far fa-eye'></i></a>-->
                                    <form action="cud.php" method="POST">
                                        <button type="submit" name="delete-officer" value="<?=$row->id; ?>"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                                    <?php
                                }
                            }else{
                                ?><?php        
                            } 
                            ?>
                         </tbody>
                    </table>
                    </div>

                    <div id="User" class="w3-container form" style="display:none">
                    <div class="user_header">
                            <h2> &emsp;JAILER LIST</h2>
                            <button class="open-button" onclick="openReg3()">Open Form</button>
                       <div class="form-popup" id="regForm3">
                            <form action="cud.php" method="POST" class="form-container">
                                <br>
                                <h1>Jailer Form</h1>
                                <br>
                                <div class="name_hold">
                                <div class="name_hold">
                            <label for="aln">Last Name:</label>
                            <input type="text" name="lastname" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="afn"> First Name:</label>
                            <input type="text" name="firstname" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="amn">Middle Name:</label>
                            <input type="text" name="middlename" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="aun">Username:</label>
                            <input type="text" name="uname" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="apw">Password:</label>
                            <input type="text" name="pword" id="m">
                            </div>
                            <div class="name_hold">
                            <label for="aem">Email:</label>
                            <input type="text" name="email" id="m">
                            </div>
                            <br>
                <button type="submit" class="btn" name="save-jailer">Save</button>
                <button type="button" class="btn cancel" onclick="closeReg3()">Close</button>
            </form>
            </div>
                        </div>
                        <table class="user_table">
                         <thead>
                            <tr>
                                <th>Date Create</th>
                                <th>Full Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                         </thead>
                         <tbody>
                            <?php

                            $query = "SELECT * FROM jailer";
                            $statement = $pdo->prepare($query);
                            $statement->execute();
                            $result = $statement->fetchAll(PDO::FETCH_OBJ);
                            if($result){
                                foreach($result as $row ){
                                ?>
                                
                            <tr>
                                <td><?= $row->date_create;?></td>
                                <td><?= $row->lastname, ', ' , $row->firstname, ' ',$row->middlename ;?></td>
                                <td><?= $row->uname;?></td>
                                <td><?= $row->email;?></td>
                                <td>
                                    <a href="a_acc_j_update.php?id=<?=$row->id; ?>"><i class='fas fa-edit'></i></a>
                                    <!--<a href="aauview.php?id=<?=$row->id; ?>"><i class='far fa-eye'></i></a>-->
                                    <form action="cud.php" method="POST">
                                        <button type="submit" name="delete-jailer" value="<?=$row->id; ?>"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                                    <?php
                                }
                            }else{
                                ?><?php        
                            } 
                            ?>
                         </tbody>
                    </table>
                    </div>
        </div>
    </main>
    
    <div class="header_hold">
    <?php include ('template/a_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/a_footer.php');?>
    </div>
</body>
</html>