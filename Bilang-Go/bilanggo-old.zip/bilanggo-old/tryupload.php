<form action="upload.php" method="post" enctype="multipart/form-data" >
    <label for="file"> Select File: </label>
    <input type="file" name="file" id="file" required>

    <input type="submit" value="Upload">
</form>