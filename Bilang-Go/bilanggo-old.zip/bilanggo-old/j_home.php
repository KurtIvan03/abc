<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: jailer.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JAILER</title>
    <link rel="stylesheet" href="design/dashboard.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/j_nav.php');?>
    </div>
 
    <main class="output">
        <div class="head_header">
            <h2>Welcome 
                <?php
                echo ' '.$_SESSION['uname']. ' !';
                ?>
            </h2>
            <script>function display_ct6() {
            var x = new Date()
            var ampm = x.getHours( ) >= 12 ? ' PM' : ' AM';
            hours = x.getHours( ) % 12;
            hours = hours ? hours : 12;
            var x1=x.getMonth() + 1+ "/" + x.getDate() + "/" + x.getFullYear(); 
            x1 = x1 + " - " +  hours + ":" +  x.getMinutes() + ":" +  x.getSeconds() + ":" + ampm;
            document.getElementById('ct6').innerHTML = x1;
            display_c6();
            }
            function display_c6(){
            var refresh=1000; // Refresh rate in milli seconds
            mytime=setTimeout('display_ct6()',refresh)
            }
            display_c6()
            </script>
            <span id='ct6'></span>
        </div>


        <div class="totalinmate"><br>
        <i class='fas fa-user-alt'></i>
        <br>
        <?php 
             $query1 = "SELECT * FROM inmate";
             $stmt1 = $pdo->prepare($query1);
             $stmt1->execute();
             $total1 = $stmt1->rowCount();
             echo "Total inmate " . $total1;
        ?>
        </div>
        <div class="totalvisitor">
            <br>
            <i class='far fa-file-alt'></i>
            <br>
        <?php 
             $query2 = "SELECT * FROM visitor";
             $stmt2 = $pdo->prepare($query2);
             $stmt2->execute();
             $total2 = $stmt2->rowCount(); 
             echo "Total Visitor " . $total2;
        ?>
        </div>
       
    </main>   <div class="header_hold">
    <?php include ('template/j_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/j_footer.php');?>
    </div>
    
</body>
</html>