<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: officer.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OFFICER</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/celll.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/o_nav.php');?>
    </div>
    
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Cell List</h2>    
            </div>     
            <div class="s_hold">
                <form action="o_cb_search.php" method="get">
                <input type="text" name="search_term" id="search_term" placeholder="Search" required>
                <button type="submit" value="Search" id="sbtn"><i class="fas fa-search"></i></button>   
                </form>
            </div>
            <table class="prison_table">
                         <thead>
                            <tr>
                                <th>Date Created</th>
                                <th>Prison Name</th>
                                <th>Cell Name</th>
                                <th>Status</th>
                            </tr>
                         </thead>
                        <tbody>
                        <?php 
                        $statement = $pdo->prepare("SELECT * FROM cell 
                        LEFT JOIN prison ON cell.prisonid = prison.prison_id");
                        $statement->execute ();
                        $result = $statement->fetchAll();

                        foreach ($result as $row) {
                            $cell_id = $row['cell_id'];
                            $cell_name = $row['cell_name'];
                            $prison_name = $row['prison_name'];
                            $cell_date_create = $row['cell_date_create'];
                            $cell_status = $row['cell_status'];
                        ?>
                             <tr>
                                <td id="m<?= $cell_date_create ?>"><?= $cell_date_create ?></td>
                                <td id="m<?= $prison_name ?>"><?= $prison_name ?></td>
                                <td id="m<?= $cell_name ?>"><?= $cell_name ?></td> 
                                <td id="m<?= $cell_status ?>"><?php
                                      if($cell_status == 1){
                                        echo "Active";
                                    } else {
                                        echo "Inactive";
                                    }
                                    ?></td> 
                               
                            </tr>
                            <?php
                        }
                    ?>
                         </tbody>
                    </table>
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/o_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/o_footer.php');?>
    </div>
</body>
</html>