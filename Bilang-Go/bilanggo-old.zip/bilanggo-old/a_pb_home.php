<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/prison.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/a_nav.php');?>
    </div>
    <main class="output">
        <div class="holder">
            <div class="button_hold">
            <h2>Prison List</h2>    
           <a href="a_pb_create.php"> <button class="create-button"><i class='fas fa-plus-circle'></i>&ensp;Create New</button> </a>
            </div>         
           
            <div class="s_hold">
                <form action="a_pb_search.php" method="get">
                <input type="text" name="search_term" id="search_term" placeholder="Search" required>
                <button type="submit" value="Search" id="sbtn"><i class="fas fa-search"></i></button>   
                </form>
            </div>
            <table class="prison_table">
                         <thead>
                            <tr>
                                <th>Date Created</th>
                                <th>Prison Name</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                         </thead>
                         <tbody>
                            <?php

                            $query = "SELECT * FROM prison";
                            $statement = $pdo->prepare($query);
                            $statement->execute();
                            $result = $statement->fetchAll(PDO::FETCH_OBJ);
                            if($result){
                                foreach($result as $row ){
                                ?>
                            <tr>
                                <td><?= $row->date_create;?></td>
                                <td><?= $row->prison_name;?></td>
                                <td>
                                <?php
                                      if($row->prison_status == 1){
                                        echo "Active";
                                    } else {
                                        echo "Inactive";
                                    }
                                    ?>
                                </td>
                                
                                <td>
                                    <a href="a_pb_update.php?id=<?=$row->prison_id; ?>"><i class='fas fa-edit'></i></a>
                                    <form action="cud.php" method="POST">
                                        <button type="submit" name="delete-prison" value="<?=$row->prison_id; ?>"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                                    <?php
                                }
                            }else{
                                ?><?php                
                            } 
                            ?>
                         </tbody>
                    </table>

        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/a_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/a_footer.php');?>
    </div>
</body>
</html>