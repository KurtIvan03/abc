<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
    $searchTerm = $_GET['search_term'];
    $sql = "SELECT * FROM cell
    INNER JOIN prison ON cell.cell_id = prison.prison_id
    WHERE cell.cell_name LIKE ? OR prison.prison_name LIKE ?";

$stmt = $pdo->prepare($sql);
$stmt->bindValue(1, '%' . $searchTerm . '%');
$stmt->bindValue(2, '%' . $searchTerm . '%');
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/celll.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/a_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Cell Search Result</h2>
            <a href="a_cb_home.php"><button class="open-button">Back</button></a> 
            </div>         
            <table class="prison_table">
            <tr>
                <th>Date Created</th>
                <th>Prison Name</th>
                <th>Cell Name</th>
                <th>Status</th>
            </tr>
            <?php if (empty($results)): ?>
                    <tr>
                        <td colspan="4">No data available.</td>
                    </tr>
                <?php else: ?>
            <?php foreach ($results as $row): ?>
                <tr>
                <?php 
                        $statement = $pdo->prepare("SELECT * FROM cell 
                        LEFT JOIN prison ON cell.prisonid = prison.prison_id");
                        $statement->execute ();
                        $result = $statement->fetchAll();

                        foreach ($result as $row) {
                            $cell_id = $row['cell_id'];
                            $cell_name = $row['cell_name'];
                            $prison_name = $row['prison_name'];
                            $cell_date_create = $row['cell_date_create'];
                            $cell_status = $row['cell_status'];
                        ?>
                    <td><?php echo $row['cell_date_create']; ?></td>
                    <td><?php echo $row['prison_name']; ?></td>
                    <td><?php echo $row['cell_name']; ?></td>
                    <td>
                    <?php
                    if($row['cell_status'] == 1){
                        echo "Active";
                    } else {
                        echo "Inactive";
                    }
                ?>
                    </td> 
                </tr>
                <?php
                        }
                    ?>
                <?php endforeach; ?>
                <?php endif; ?>
        </table>
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/a_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/a_footer.php');?>
    </div>
</body>
</html>