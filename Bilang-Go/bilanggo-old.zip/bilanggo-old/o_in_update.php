<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
    if(isset($_GET['id'])){
        $inmate_id = $_GET['id'];
 
        $query = "SELECT * FROM inmate WHERE inmate_id=:id";
        $statement = $pdo->prepare($query);
        $data = [':id' => $inmate_id];
        $statement->execute($data);
 
        $result = $statement->fetch(PDO::FETCH_OBJ); //ASSOC
    }
    define('Single', 'Single');
define('Merried', 'Merried');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/inmate_form.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/o_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Update</h2>    
            <a href="o_in_home.php"><button class="newbtn">Back</button></a>  
            </div>         
            <div class="form_hold">
            <form action="cud.php" method="POST" class="form-container">  
                <input type="hidden" name="inmate_id" value="<?= $result->inmate_id;?>">
                <div class="img_hold">
                    <p>Image <br> Not <br> Available</p>
                </div>              
                <div class="con1">
                    <label for="inln">Last Name:</label>
                    <input type="text" name="lastname" value="<?= $result->lastname;?>">
                </div>
                <div class="con2">
                    <label for="infn"> First Name:</label>
                    <input type="text" name="firstname" value="<?= $result->firstname;?>">
                </div>
                <div class="con3">
                    <label for="inmn">Middle Name:</label>
                    <input type="text" name="middlename"value="<?= $result->middlename;?>" >
                </div>
                <div class="con4">
                    <label for="inbd">Birthday:</label>
                    <input type="date" name="bday" value="<?= $result->bday;?>">
                </div>
                <div class="con5">
                    <label for="ingen">Gender:</label>
                    <select name="gender" value="<?= $result->gen;?>">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div class="con6">
                    <label for="insta">Status:</label>
                    <select name="prison_status" id="m">
    <option value="Single" <?= ($result->statuss == 'Single' ? 'selected' : '') ?> >Active</option>
    <option value="Merried" <?= ($result->statuss == 'Merried' ? 'selected' : '') ?> >Inactive</option>
</select>
                </div>
                <div class="con7">
                    <label for="inprk" id="inprklabel">Street:</label>
                    <input type="text" name="street" id="inprk" value="<?= $result->street;?>">
               <br>
                    <label for="inbr" id="inbrlabel"> Barangay:</label>
                    <input type="text" name="barangay" id="inbr" value="<?= $result->barangay;?>">
              <br>
                    <label for="inmu" id="inmulabel">Municipality:</label>
                    <input type="text" name="municipality" id="inmu" value="<?= $result->municipality;?>">
           <br>
                    <label for="inpro" id="inprolabel">Province:</label>
                    <input type="text" name="province" id="inpro" value="<?= $result->province;?>">
              <br>
                    <label for="inco"id="incolabel">Country:</label>
                    <input type="text" name="country" id="inco" value="<?= $result->country;?>">
                </div>
            <div class="crimedetails">
                <h2>Crime Details</h2>
                <div class="con8">
                    <label for="inpc">Prison Code:</label>
                    <input type="text" name="prison_code" value="<?= $result->prison_code;?>">
                </div>
               <div class="con9">
                    <label for="inpbcb">Prison Block:</label>
                    <select name="cellname" id="prison" value="<?= $result->prisonname;?>">
                        <option value="">Select</option>
                        <?php 
                            $statements1 = $pdo->prepare("SELECT * FROM prison");
                            $statements1->execute();
                            $results1 = $statements1->fetchAll();
                            foreach ($results1 as $row1) {
                                $prison_id = $row1['prison_id'];
                                $name = $row1['prison_name'];
                                ?>
                                <option value="<?= $prison_id ?>"><?= $name ?> Prison</option>
                                <?php
                            }
                        ?>
                        </select>
                </div>
               <div class="con99">
                    <label for="inpbcb">Cell Block:</label>
                    <select name="cellname" id="prison" value="<?= $result->cellname;?>">
                        <option value="">Pre Select</option>
                        <?php 
                            $statements2 = $pdo->prepare("SELECT * FROM cell");
                            $statements2->execute();
                            $results2 = $statements2->fetchAll();
                            foreach ($results2 as $row2) {
                                $cell_id = $row2['cell_id'];
                                $cell_name = $row2['cell_name'];
                                ?>
                                <option value="<?= $cell_id ?>"><?= $cell_name ?> Prison</option>
                                <?php
                            }
                        ?>
                        </select>
                </div>
                <div class="con10">
                    <label for="incr">Crime:</label>
                    <input type="text" name="crime" value="<?= $result->crime;?>">
                </div>
                <div class="con11">
                    <label for="insen">Sentence:</label>
                    <input type="text" name="sentence" value="<?= $result->sentence;?>">
                </div> 
                <div class="con12">
                    <label for="intds">Time Date Start:</label>
                    <input type="date" name="tds" value="<?= $result->tds;?>">
                </div>
                <div class="con13">
                    <label for="intde">Time Date End:</label>
                    <input type="date" name="tde" value="<?= $result->tde;?>">
                </div>
                </div><br>
                    <button type="submit" class="btn" name="update-in">Update</button>
                </form>
                <a href="o_in_home.php"><button class="cancelbtn">Cancel</button></a>
            </div>
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/o_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/o_footer.php');?>
    </div>
</body>
</html>