<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    } 
    if(isset($_GET['id'])){
        $cell_id = $_GET['id'];
 
        $query = "SELECT * FROM cell WHERE cell_id=:id LIMIT 1";
        $statement = $pdo->prepare($query);
        $data = [':id' => $cell_id];
        $statement->execute($data);
        $result = $statement->fetch(PDO::FETCH_OBJ); //ASSOC
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/celll.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/a_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Update Cell Details</h2>    
            </div>         
            <form action="cud.php" method="POST" class="form-container">
                        <input type="hidden" name="cell_id" value="<?= $result->cell_id;?>">
                        <div class="prison_name">
                            <label for="pbnm">Cell Name:</label><br>
                            <input type="text"  name="cell_name" value="<?= $result->cell_name;?>">
                            
                        </div>
                        <div class="prison_status">
                            <label for="pbsta">Prison Name</label>
                            <br>
                            <select name="prisonid" id="prisonid">
                            <option value="">-pre select-</option>
                                <?php
                                    $statement = $pdo->prepare("SELECT * FROM prison");
                                    $statement->execute();

                                    $results = $statement->fetchAll();

                                    foreach ($results as $row) {
                                        $prison_id = $row['prison_id'];
                                        $prison_name = $row['prison_name'];
                                        ?>
                                        <option value="<?= $prison_id ?>"><?= $prison_name ?> </option>
                                        <?php
                                    }?>
                            </select>
                        </div>
                        <div class="prison_status">
                            <label for="pbsta">Status</label>
                            <br>
                            <select name="cell_status" id="m">
                                <option value="1" <?= ($result->cell_status == 1 ? 'selected' : '') ?> >Active</option>
                                <option value="0" <?= ($result->cell_status == 0 ? 'selected' : '') ?> >Inactive</option>
                            </select>
                        </div>
                            <br><br>
                    <button type="submit" class="create"name="update-cell">CREATE</button>
                  
                </form>
            <a href="a_cb_home.php"><button id="cancel">CANCEL</button></a>
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/a_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/a_footer.php');?>
    </div>
</body>
</html>