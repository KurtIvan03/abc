<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
    
$searchTerm = $_GET['search_term'];
$sql = "SELECT * FROM inmate 
        WHERE 
         inmate.lastname LIKE :searchTerm 
        OR inmate.firstname LIKE :searchTerm 
        OR inmate.lastname LIKE :searchTerm 
        OR inmate.middlename LIKE :searchTerm 
        OR inmate.date_create LIKE :searchTerm";

$stmt = $pdo->prepare($sql);
$stmt->bindValue(':searchTerm' ,'%' . $searchTerm . '%');
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/inmate.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/o_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Inmate Data Result</h2>    
            <a href="o_in_home.php"><button class="newbtn">Back</button></a>  
            </div>         
            <table class="prison_table">
                <tr>
                    <th>Date Created</th>
                    <th>Prison Code</th>
                    <th>Full Name</th>
                    <th>Prison Name & Cell Name</th>
                </tr>
                <?php if (empty($results)): ?>
                    <tr>
                        <td colspan="4">No data available.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($results as $row): ?>
                        <tr>
                            <td><?php echo $row['date_create']; ?></td>
                            <td><?php echo $row['prison_code']; ?></td>
                            <td><?php echo $row['lastname'], ', ', $row['firstname'] , ' ' , $row['middlename']; ?></td>
                            <td><?php echo $row['cellname']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </table>
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/o_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/o_footer.php');?>
    </div>
</body>
</html>