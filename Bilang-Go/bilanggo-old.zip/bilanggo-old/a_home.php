<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">

</head>
<body>
   
<div class="navigation_hold">
        <?php include ('template/a_nav.php');?>
    </div>
    <main class="output">
        <div class="head_header">
            <h2>Welcome 
                <?php
                echo ' '.$_SESSION['uname']. ' !';
                ?>
            </h2>
            <script>function display_ct6() {
            var x = new Date()
            var ampm = x.getHours( ) >= 12 ? ' PM' : ' AM';
            hours = x.getHours( ) % 12;
            hours = hours ? hours : 12;
            var x1=x.getMonth() + 1+ "/" + x.getDate() + "/" + x.getFullYear(); 
            x1 = x1 + " - " +  hours + ":" +  x.getMinutes() + ":" +  x.getSeconds() + ":" + ampm;
            document.getElementById('ct6').innerHTML = x1;
            display_c6();
            }
            function display_c6(){
            var refresh=1000; // Refresh rate in milli seconds
            mytime=setTimeout('display_ct6()',refresh)
            }
            display_c6()
            </script>
            <span id='ct6'></span>
        </div>


        <div class="totalinmate"><br>
        <i class='fas fa-user-alt'></i>
        <br>
        <?php 
             $query1 = "SELECT * FROM inmate";
             $stmt1 = $pdo->prepare($query1);
             $stmt1->execute();
             $total1 = $stmt1->rowCount();
             echo "Total inmate " . $total1;
        ?>
        </div>
        <div class="totalvisitor">
            <br>
            <i class='far fa-file-alt'></i>
            <br>
        <?php 
             $query2 = "SELECT * FROM visitor";
             $stmt2 = $pdo->prepare($query2);
             $stmt2->execute();
             $total2 = $stmt2->rowCount(); 
             echo "Total Visitor " . $total2;
        ?>
        </div>
        <div class="totalcell">
        <br><i class='fas fa-border-all'></i>
        <br>
            <?php 
             $query3 = "SELECT * FROM cell";
             $stmt3 = $pdo->prepare($query3);
             $stmt3->execute();
             $total3 = $stmt3->rowCount();
             echo "Total Cell Block " . $total3;
        ?>

        </div>
        <div class="totalprison">
        <br><i class='fas fa-list'></i>
        <br>
        <?php 
             $query4 = "SELECT * FROM prison";
             $stmt4 = $pdo->prepare($query4);
             $stmt4->execute();
             $total4 = $stmt4->rowCount();
             echo "Total Prison Block " . $total4;
        ?>
        </div>
        <div class="totaladminacc">
        <br>
        <i class='fas fa-user-cog'></i>
        <br>
        <?php 
             $query5 = "SELECT * FROM admin";
             $stmt5 = $pdo->prepare($query5);
             $stmt5->execute();
             $total5 = $stmt5->rowCount();
             echo "Total Admin Account " . $total5;
        ?>
        </div>
        <div class="totalassistantacc">
        <br>
        <i class='fas fa-user-cog'></i>
        <br>
        <?php 
             $query6 = "SELECT * FROM officer";
             $stmt6 = $pdo->prepare($query6);
             $stmt6->execute();
             $total6 = $stmt6->rowCount();
             echo "Total Officer Account " . $total6;
        ?>
        </div>
        <div class="totaluseracc">
            <br><i class='fas fa-user-cog'></i>&ensp;
        <br>
        <?php 
             $query7 = "SELECT * FROM jailer";
             $stmt7 = $pdo->prepare($query7);
             $stmt7->execute();
             $total7 = $stmt7->rowCount();
             echo "Total Jailer Account " . $total7;
        ?>
        </div>
       
    </main>
    <div class="header_hold">
    <?php include ('template/a_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/a_footer.php');?>
    </div>
    
</body>
</html>