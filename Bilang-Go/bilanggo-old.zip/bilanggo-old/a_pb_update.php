<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
    
    if(isset($_GET['id'])){
        $prison_id = $_GET['id'];
 
        $query = "SELECT * FROM prison WHERE prison_id=:id LIMIT 1";
        $statement = $pdo->prepare($query);
        $data = [':id' => $prison_id];
        $statement->execute($data);
 
        $result = $statement->fetch(PDO::FETCH_OBJ); //ASSOC
 
     }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/prison.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/a_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Update Prison Details</h2>    
            </div>         
            <form action="cud.php" method="POST" class="form-container">
                        <input type="hidden" name="prison_id" value="<?= $result->prison_id;?>">
                        <div class="prison_name">
                            <label for="pbnm">Prison Name:</label><br>
                            <input type="text"  name="prison_name" value="<?= $result->prison_name;?>">
                            
                        </div>
                        <div class="prison_status">
                            <label for="status">Status</label>
                            <br>
                            <select name="prison_status" id="m">
                                <option value="1" <?= ($result->prison_status == 1 ? 'selected' : '') ?> >Active</option>
                                <option value="0" <?= ($result->prison_status == 0 ? 'selected' : '') ?> >Inactive</option>
                            </select>
                        </div>
                            <br><br>
                    <button type="submit" class="create"name="update-prison">UPDATE</button>
                  
                </form>
            <a href="a_pb_home.php"><button id="cancel">CANCEL</button></a>
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/a_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/a_footer.php');?>
    </div>
</body>
</html>