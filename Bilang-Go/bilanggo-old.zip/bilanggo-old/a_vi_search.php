<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
    $searchTerm = $_GET['search_term'];
    $sql = "SELECT * FROM visitor WHERE inmateid LIKE :searchTerm OR lastname LIKE :searchTerm 
    OR firstname LIKE :searchTerm OR lastname LIKE :searchTerm OR
    relationship LIKE :searchTerm OR
    contact LIKE :searchTerm OR
    middlename LIKE :searchTerm OR vi_date_create LIKE :searchTerm";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':searchTerm' ,'%' . $searchTerm . '%');
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/visitorpage.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/a_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Visitor Search Result</h2>    
            <a href="a_vi_home.php"><button class="open-button">Back</button></a>
            </div>         
            <table class="prison_table">
            <tr>
                <th>Date Created</th>
                <th>Prison Code</th>
                <th>Full Name</th>
                <th>Relationship</th>
                <th>Contact</th>
            </tr> <?php if (empty($results)): ?>
                    <tr>
                        <td colspan="4">No data available.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($results as $row): ?>
                        <tr>
                            <td><?php echo $row['vi_date_create']; ?></td>
                            <td><?php echo $row['inmateid']; ?></td>
                            <td><?php echo $row['lastname'], ', ', $row['firstname'] , ' ' , $row['middlename']; ?></td>
                            <td><?php echo $row['relationship']; ?></td>
                            <td><?php echo $row['contact']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
        </table>
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/a_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/a_footer.php');?>
    </div>
</body>
</html>