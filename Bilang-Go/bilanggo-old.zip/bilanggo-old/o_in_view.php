<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
    if(isset($_GET['id'])){
        $inmate_id = $_GET['id'];
        $query = "SELECT * FROM inmate WHERE inmate_id=:id LIMIT 1";
        $statement = $pdo->prepare($query);
        $data = [':id' => $inmate_id];
        $statement->execute($data);
        $result = $statement->fetch(PDO::FETCH_OBJ); //ASSOC
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OFFICER</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/inmate_form.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/o_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>View</h2>    
            <a href="o_in_home.php"><button class="newbtn">Back</button></a>  
            </div>         
            <div class="form_hold">
            <form action="cud.php" method="POST" class="form-container">  
                <input type="hidden" name="inmate_id" value="<?= $result->inmate_id;?>">
                <div class="img_hold">
                    <p>Image <br> Not <br> Available</p>
                </div>              
                <div class="con1">
                    <label for="inln">Last Name:</label>
                    <input type="text" name="lastname" value="<?= $result->lastname;?>"readonly>
                </div>
                <div class="con2">
                    <label for="infn"> First Name:</label>
                    <input type="text" name="firstname" value="<?= $result->firstname;?>"readonly>
                </div>
                <div class="con3">
                    <label for="inmn">Middle Name:</label>
                    <input type="text" name="middlename"value="<?= $result->middlename;?>" readonly>
                </div>
                <div class="con4">
                    <label for="inbd">Birthday:</label>
                    <input type="date" name="bday" value="<?= $result->bday;?>"readonly>
                </div>
                <div class="con5">
                    <label for="ingen">Gender:</label>
                    <input type="text" value="<?= $result->gender;?>" readonly>
                    
                </div>
                <div class="con6">
                    <label for="insta">Status:</label>
                    <input type="text" name="statuss" value="<?= $result->statuss;?>"readonly>
                        
                </div>
                <div class="con7">
                    <label for="inprk" id="inprklabel">Street:</label>
                    <input type="text" name="street" id="inprk" value="<?= $result->street;?>" readonly>
               <br>
                    <label for="inbr" id="inbrlabel"> Barangay:</label>
                    <input type="text" name="barangay" id="inbr" value="<?= $result->barangay;?>" readonly>
              <br>
                    <label for="inmu" id="inmulabel">Municipality:</label>
                    <input type="text" name="municipality" id="inmu" value="<?= $result->municipality;?>" readonly>
           <br>
                    <label for="inpro" id="inprolabel">Province:</label>
                    <input type="text" name="province" id="inpro" value="<?= $result->province;?>"readonly>
              <br>
                    <label for="inco"id="incolabel">Country:</label>
                    <input type="text" name="country" id="inco" value="<?= $result->country;?>" readonly>
                </div>
            <div class="crimedetails">
                <h2>Crime Details</h2>
                <div class="con8">
                    <label for="inpc">Prison Code:</label>
                    <input type="text" name="prison_code" value="<?= $result->prison_code;?>" readonly>
                </div>
               <div class="con9">
                    <label for="inpbcb">Prison Block:</label>
                    <input type="text" name="prisonname" id="prison" value="<?= $result->prisonname;?>" readonly>
                       
                </div>
               <div class="con99">
                    <label for="inpbcb">Cell Block:</label>
                    <input type="text" name="cellname" id="prison" value="<?= $result->cellname;?>" readonly>
                       
                </div>
                <div class="con10">
                    <label for="incr">Crime:</label>
                    <input type="text" name="crime" value="<?= $result->crime;?>"readonly>
                </div>
                <div class="con11">
                    <label for="insen">Sentence:</label>
                    <input type="text" name="sentence" value="<?= $result->sentence;?>" readonly>
                </div> 
                <div class="con12">
                    <label for="intds">Time Date Start:</label>
                    <input type="date" name="tds" value="<?= $result->tds;?>" readonly>
                </div>
                <div class="con13">
                    <label for="intde">Time Date End:</label>
                    <input type="date" name="tde" value="<?= $result->tde;?>" readonly>
                </div>
                </div><br>
                </form>
            </div>
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/o_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/o_footer.php');?>
    </div>
</body>
</html>