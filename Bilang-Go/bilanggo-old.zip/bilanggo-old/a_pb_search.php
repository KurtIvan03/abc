<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
    $searchTerm = $_GET['search_term'];
    $sql = "SELECT * FROM prison WHERE prison_name LIKE :searchTerm OR prison_status LIKE :searchTerm OR date_create LIKE :searchTerm";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':searchTerm' ,'%' . $searchTerm . '%');
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/prison.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/a_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Prison Search Result</h2> 
            <a href="a_pb_home.php"><button class="create-button">Back</button></a>
            </div>         
            <table class="prison_table">
            <tr>
                <th>Date Created</th>
                <th>Prison Name</th>
                <th>Status</th>
            </tr>
            <?php foreach ($results as $row): ?>
                <tr>
                    <td><?php echo $row['date_create']; ?></td>
                    <td><?php echo $row['prison_name']; ?></td>
                    <td>
                    <?php
                    if($row['prison_status'] == 1){
                        echo "Active";
                    } else {
                        echo "Inactive";
                    }
                ?>
                                </td>
                </tr>
                
                <?php endforeach; ?>
        </table>
           
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/a_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/a_footer.php');?>
    </div>
</body>
</html>