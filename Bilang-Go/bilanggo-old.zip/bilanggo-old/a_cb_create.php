<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/celll.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/a_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>New Cell Details</h2>    
            </div>         
            <form action="cud.php" method="POST" class="form-container">
                        
                        <div class="prison_name">
                            <label for="name">Cell Name:</label><br>
                            <input type="text"  name="cell_name">
                            
                        </div>
                        <div class="prison_status">
                            <label for="prisonid">Prison Name</label>
                            <br>
                           <select name="prisonid" id="">
                            <option value="">-select-</option>

                            <?php 
                                $statement = $pdo->prepare("SELECT * FROM prison");
                                $statement->execute();

                                $result = $statement->fetchAll();

                                foreach ($result as $row) {
                                    $prisonid = $row['prison_id'];
                                    $name = $row['prison_name'];
                                    ?>
                                    <option value="<?= $prisonid ?>"><?= $name ?> Prison</option>
                                    <?php
                                }
                            ?>
                            </select>
                        </div>
                        <div class="prison_status">
                            <label for="pbsta">Status</label>
                            <br>
                            <select name="cell_status" id="m">
                                <option value="1" name="cell_status">Active</option>
                                <option value="0" name="cell_status">Inactive</option>
                            </select>
                        </div>
                            <br><br>
                    <button type="submit" class="create"name="save-cell">CREATE</button>
                  
                </form>
            <a href="a_cb_home.php"><button id="cancel">CANCEL</button></a>
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/a_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/a_footer.php');?>
    </div>
</body>
</html>