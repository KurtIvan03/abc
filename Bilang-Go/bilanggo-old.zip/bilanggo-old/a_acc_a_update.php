<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    } if(isset($_GET['id'])){
        $id = $_GET['id'];
        $query = "SELECT * FROM admin WHERE id=:id LIMIT 1";
        $statement = $pdo->prepare($query);
        $data = [':id' => $id];
        $statement->execute($data);
        $result = $statement->fetch(PDO::FETCH_OBJ); //ASSOC
     }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/account_update.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/a_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Update Admin Account</h2>    
            </div>         
            <form action="cud.php" method="POST" class="form-container">
                <br><br>
                    <div class="name_hold">
                <label for="uln">Last Name:</label>
                <input type="hidden" name="id" id="input" value="<?= $result->id;?>">
                <input type="text" name="lastname" id="input" value="<?= $result->lastname;?>">
                </div>
                <div class="name_hold">
                <label for="ufn"> First Name:</label>
                <input type="text" name="firstname" id="input"value="<?= $result->firstname;?>">
                </div>
                <div class="name_hold">
                <label for="umn">Middle Name:</label>
                <input type="text" name="middlename" id="input"value="<?= $result->middlename;?>">
                </div>
                <div class="name_hold">
                <label for="uun">Username:</label>
                <input type="text" name="uname" id="input"value="<?= $result->uname;?>">
                </div>
                <div class="name_hold">
                <label for="upw">Password:</label>
                <input type="text" name="pword" id="input"value="<?= $result->pword;?>">
                </div>
                <div class="name_hold">
                <label for="uem">Email:</label>
                <input type="text" name="email" id="input"value="<?= $result->email;?>">
                </div>
                <br><br><br>
                <button type="submit" class="btn" name="update-admin">Save</button>
                <a href="a_acc_home.php"><button type="button" class="btn cancel" >Close</button></a>
            </form>
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/a_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/a_footer.php');?>
    </div>
</body>
</html>