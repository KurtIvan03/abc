

<?php

include ('data.php');
$uploadDir = 'uploads/';

if(isset($_FILES['file'])){
    $fileName = $_FILES['file']['name'];
    $filePath = $uploadDir . $fileName;

    move_uploaded_file($_FILES['file']['tmp_name'], $filePath);
    $sql = "INSERT INTO files (file_path) VALUES (:filePath)";

    $sql = $pdo->prepare($sql);
    $stmt ->bindParam(':filePath', $filePath);

    if($stmt->execute()){
    echo "File uploaded Successfully!";
        } else{
        echo "Error";
        }

}
?>