<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OFFICER</title>
    <link rel="stylesheet" href="design/dashboard.css">
   <!-- <link rel="stylesheet" href="design/inmate.css">-->
    <link rel="stylesheet" href="design/inmate_form.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/o_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Create New</h2>    
            <a href="o_in_home.php"><button class="newbtn">Back</button></a>  
            </div>         
           
            <div class="form_hold">
            <form action="cud.php" method="POST" class="form-container">  
                <div class="img_hold">
                    <p>Image <br> Not <br> Available</p>
                </div>              
                <div class="con1">
                    <label for="inln">Last Name:</label>
                    <input type="text" name="lastname">
                </div>
                <div class="con2">
                    <label for="infn"> First Name:</label>
                    <input type="text" name="firstname">
                </div>
                <div class="con3">
                    <label for="inmn">Middle Name:</label>
                    <input type="text" name="middlename" >
                </div>
                <div class="con4">
                    <label for="inbd">Birthday:</label>
                    <input type="date" name="bday">
                </div>
                <div class="con5">
                    <label for="ingen">Gender:</label>
                    <select name="gender">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div class="con6">
                    <label for="insta">Status:</label>
                    <select name="statuss">
                        <option value="Single">Single</option>
                        <option value="Married">Married</option>
                    </select>
                </div>
                <div class="con7">
                    <label for="inprk" id="inprklabel">Street:</label>
                    <input type="text" name="street" id="inprk">
               <br>
                    <label for="inbr" id="inbrlabel"> Barangay:</label>
                    <input type="text" name="barangay" id="inbr">
              <br>
                    <label for="inmu" id="inmulabel">Municipality:</label>
                    <input type="text" name="municipality" id="inmu">
           <br>
                    <label for="inpro" id="inprolabel">Province:</label>
                    <input type="text" name="province" id="inpro">
              <br>
                    <label for="inco"id="incolabel">Country:</label>
                    <input type="text" name="country" id="inco">
                </div>
            <div class="crimedetails">
                <h2>Crime Details</h2>
                <div class="con8">
                    <label for="inpc">Prison Code:</label>
                    <input type="text" name="prison_code">
                </div>
               <div class="con9">
                    <label for="inpbcb">Prison Block:</label>
                    <select name="prisonname" id="prison">
                        <option value="">-select-</option>
                        <?php 
                            $statement1 = $pdo->prepare("SELECT * FROM prison");
                            $statement1->execute();
                            $result1 = $statement1->fetchAll();
                            foreach ($result1 as $row1) {
                                $prisonid = $row1['prison_id'];
                                $name = $row1['prison_name'];
                                ?>
                                <option value="<?= $prisonid ?>"><?= $name ?> Prison</option>
                                <?php
                            }
                        ?>
                        </select>
                </div>
               <div class="con99">
                    <label for="inpbcb">Cell Block:</label>
                    <select name="cellname" id="prison">
                        <option value="">-select-</option>
                        <?php 
                            $statement2 = $pdo->prepare("SELECT * FROM cell");
                            $statement2->execute();
                            $result2 = $statement2->fetchAll();
                            foreach ($result2 as $row2) {
                                $cell_id = $row2['cell_id'];
                                $cell_name = $row2['cell_name'];
                                ?>
                                <option value="<?= $cell_id ?>"><?= $cell_name ?> Cell</option>
                                <?php
                            }
                        ?>
                        </select>
                </div>
                <div class="con10">
                    <label for="incr">Crime:</label>
                    <input type="text" name="crime">
                </div>
                <div class="con11">
                    <label for="insen">Sentence:</label>
                    <input type="text" name="sentence">
                </div> 
                <div class="con12">
                    <label for="intds">Time Date Start:</label>
                    <input type="date" name="tds">
                </div>
                <div class="con13">
                    <label for="intde">Time Date End:</label>
                    <input type="date" name="tde">
                </div>
                </div><br>
                    <button type="submit" class="btn" name="save-inmate">Save</button>
                </form>
                <a href="o_in_home.php"><button class="cancelbtn">Cancel</button></a>
            </div>
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/o_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/o_footer.php');?>
    </div>
</body>
</html>