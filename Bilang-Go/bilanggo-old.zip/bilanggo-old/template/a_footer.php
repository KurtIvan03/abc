
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/navigation.css">
    
</head>
<body>
    <div class="footer">
        <p>© 2023 BSIT-3B</p>
        </div>


</body>
</html>