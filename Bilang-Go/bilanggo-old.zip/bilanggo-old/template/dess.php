<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/report.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/a_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Report Details</h2>    
            </div>         
           
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/a_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/a_footer.php');?>
    </div>
</body>
</html>