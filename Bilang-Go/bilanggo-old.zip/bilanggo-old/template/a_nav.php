
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN</title>
    <link rel="stylesheet" href="design/navigation.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" />
    <script defer src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" integrity="sha384-rOA1PnstxnOBLzCLMcre8ybwbTmemjzdNlILg8O7z1lUkLXozs4DHonlDtnE7fpc" crossorigin="anonymous"></script>
  
</head>
<body>
    <aside class="navbar">
        <header class="logo_hold">
            <a href="a_home.php">
                <img src="Design/logo.png">
                <h1>Bilang-Go</h1>
            </a>

        </header>
        <br>
        <a href="a_home.php"><button><i class='fab fa-microsoft'></i>&ensp;Dashboard</button></a>
        <br>
        <br>
        <div class="line"></div>
        <a href="a_cb_home.php"><button><i class='fas fa-border-all'></i>&ensp;Cell List</button></a>
        <a href="a_pb_home.php"><button><i class='fas fa-list'></i>&ensp;Prison List</button></a>
        <a href="a_acc_home.php"><button><i class='fas fa-user-cog'></i>&ensp;Account List</button></a><br><br>
        <div class="line"></div>
        <a href="a_rep_home.php"><button><i class='far fa-file-alt'></i>&ensp;Reports</button></a>
        <a href="a_in_home.php"><button><i class='fas fa-user-alt'></i>&ensp;Inmate List</button></a>
        <a href="a_vi_home.php"><button><i class='far fa-file-alt'></i>&ensp;Visitior List</button></a><br><br>
        <div class="line"></div>
        <a href="a_logout.php"><button><i class='fas fa-sign-out-alt'></i>&ensp; Log out</button></a>
    </aside>
    
</body>
</html>