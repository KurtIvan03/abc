<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: officer.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OFFICER</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/visitorpage.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/o_nav.php');?>
    </div>
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>View Details</h2>   
            <a href="o_vi_home.php"><button class="open-button">Back</button></a>  
            </div>         
           
        </div>
    </main>
    <div class="header_hold">
    <?php include ('template/o_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/o_footer.php');?>
    </div>
</body>
</html>