<?php
include("data.php");

$query1 = "SELECT * FROM inmate";
$query2 = "SELECT * FROM cell";
$query3 = "SELECT * FROM prison";

$statement1 = $pdo->prepare($query1);
$statement2 = $pdo->prepare($query2);
$statement3 = $pdo->prepare($query3);

$statement1->execute();
$statement2->execute();
$statement3->execute();

$result1 = $statement1->fetchAll();
$result2 = $statement2->fetchAll();
$result3 = $statement3->fetchAll();
?>

<table border="1">
    <tr>
        <th>Inmate ID</th>
        <th>Last Name</th>
        <th>First Name</th>
        <th>Middle Name</th>
        <th>Cell Name</th>
        <th>Date_create</th>
        <th>Prison Name</th>

    </tr><?php
 $row2_set = false;
 foreach ($result1 as $row1 ) {
    if(!$row2_set) {
      $row2 = $row1;
      $row2_set = true;
    }
?>
    <tr>
        <td><?= $row1['inmate_id'] ?></td>
        <td><?= $row1['lastname'] ?></td>
        <td><?= $row1['firstname'] ?></td>
        <td><?= $row1['middlename'] ?></td>
        
        <td> 
        <?php
          if($row1->cellname == $row2->cell_id){
            echo $row1['cellname'];
          } else {
            echo "Inactive";
          }
        ?></td>
        <td><?= $row1['date_create'] ?></td>
        
    </tr>
<?php } ?>
</table>
<br><br><br>
<?= $row1['cellname'] ?>

<table border="1">
    <tr>
        <th>Cell ID</th>
        <th>Cell Name</th>
        <th>Status</th>
        <th>Prison Name</th>
        <th>Date Create</th>
    </tr>
    <?php foreach ($result2 as $row2) { ?>
        <tr>
            <td><?= $row2['cell_id'] ?></td>
            <td><?= $row2['cell_name'] ?></td>
            <td><?= $row2['cell_status'] ?></td>
            <td><?= $row2['prisonid'] ?></td>
            <td><?= $row2['cell_date_create'] ?></td>
        </tr>
    <?php } ?>
</table>
<br><br><br>
<table border="1">
    <tr>
        <th>Prison ID</th>
        <th>Prison Name</th>
        <th>Prison Status</th>
        <th>Date Create</th>
    </tr>
    <?php foreach ($result3 as $row3) { ?>
        <tr>
            <td><?= $row3['prison_id'] ?></td>
            <td><?= $row3['prison_name'] ?></td>
            <td><?= $row3['prison_status'] ?></td>
            <td><?= $row3['date_create'] ?></td>
        </tr>
    <?php } ?>
</table>