<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: jailer.php");
    }
    if(isset($_GET['id'])){
        $inmate_id = $_GET['id'];
        $query = "SELECT * FROM inmate WHERE inmate_id=:id LIMIT 1";
        $statement = $pdo->prepare($query);
        $data = [':id' => $inmate_id];
        $statement->execute($data);
 
        $result = $statement->fetch(PDO::FETCH_OBJ); //ASSOC
 
     }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JAILER</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/visitorpage.css">

</head>
<body>
    <div class="navigation_hold">
        <?php include ('template/j_nav.php');?>
    </div>
    
    <main class="output">
    <div class="holder">
            <div class="button_hold">
            <h2>Create New Visitor</h2>    
            </div>
            <form action="cud.php" method="POST" class="form-container">
                             <br>
                                    <h1>Visitor Form</h1>
                                    <br>
                            <div class="lastname">
                                <label for="viln">Last Name:</label>
                                <input type="text" name="lastname" id="">
                            </div>
                            <div class="firstname">
                                <label for="vifn">First Name:</label>
                                <input type="text" name="firstname" id="">
                            </div>
                            <div class="lastname">
                                <label for="vimn">Middle Name:</label>
                                <input type="text" name="middlename" id="">
                            </div>
                            <div class="lastname">
                                <label for="virel">Relationship:</label>
                                <input type="text" name="relationship" id="">
                            </div>
                            <div class="lastname">
                                <label for="virel">Contact Number:</label>
                                <input type="text" name="contact" id="">
                            </div>
                            <div class="viic">
                                <label for="viic">Prison Code:</label>
                                <input type="text" name="inmateid" id="" value="<?= $result->prison_code;?>">
                            </div>
                            
                                <br><br>
                        <button type="submit" class="btn" name="save-visitor">Create</button>
                       <a href="j_in_home.php"><button type="button" class="btn cancel">Close</button></a>
                    </form>
    </div>
    </main>
    <div class="header_hold">
    <?php include ('template/j_header.php');?>
    </div>
    <div class="footer_hold">
    <?php include ('template/j_footer.php');?>
    </div>
</body>
</html>