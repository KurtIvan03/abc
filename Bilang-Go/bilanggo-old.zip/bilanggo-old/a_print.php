<?php
    session_start();
    include ('data.php');
    if(isset($_SESSION['uname'])){
         
    }else{
        header("location: admin.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OFFICER</title>
    <link rel="stylesheet" href="design/dashboard.css">
    <link rel="stylesheet" href="design/report.css">

    <script type="text/javascript">
	function PrintPage() {
		window.print();
	}
	document.loaded = function(){
		
	}
	window.addEventListener('DOMContentLoaded', (event) => {
   		PrintPage()
		setTimeout(function(){ window.close() },750)
	});
</script>  
<style>	
		.table {
			width: 100%;
			margin-bottom: 20px;
		}	
		
		.table-striped tbody > tr:nth-child(odd) > td,
		.table-striped tbody > tr:nth-child(odd) > th {
			background-color: #f9f9f9;
		}
		
		@media print{
			#print {
				display:none;
			}
		}
		@media print {
			#PrintButton {
				display: none;
			}
		}
		
		@page {
			size: auto;
			width: 8.5 in;   /* auto is the initial value */
			margin: 0;  /* this affects the margin in the printer settings */
		}
	</style>
</head>
<body>
    <div class="print">
            <div class="button_hold">
            <h2>Report Details</h2> 
               
            </div>      
           
	<h2>Print Document</h2>
	<br /> <br /> <br /> <br />
	<b style="color:blue;">Date Prepared:</b>
	<?php
		$date = date("Y-m-d", strtotime("+6 HOURS"));
		echo $date;
	?>
	<br /><br />
	<table class="table table-striped">
    <thead>
        <tr>
            <th>Date Created</th>
            <th>Prison Code</th>
            <th>Full Name</th>
            <th>Relationship</th>
            <th>Contact</th>
        </tr>
     </thead>
     <tbody>
        <?php
        $query = "SELECT * FROM visitor";
        $statement = $pdo->prepare($query);
        $statement->execute();
        $result = $statement->fetchAll(PDO::FETCH_OBJ);
        if($result){
            foreach($result as $row ){
            ?>
        <tr>
            <td><?= $row->vi_date_create;?></td>
            <td><?= $row->inmateid ;?></td>
            <td><?= $row->lastname , ', ', $row->firstname ,' ', $row->middlename ;?></td>
            <td><?= $row->relationship;?></td>
            <td><?= $row->contact;?></td>
           
        </tr>
                <?php
            }
        }else{
            ?><?php                
        } 
        ?>
     </tbody>
	</table>
	<button id="PrintButton" onclick="PrintPage()">Print</button>
    <a href="o_rep_home.php"><button class="open-button">Back</button></a>
           
        </div>
    </main>
    
</body>
</html>