<?php include ('template/a_header.php');?>
<nav class="navbar navbar-expand-lg ">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand text-black" href="#">
    <img src="assets/img/logo.png" alt="Bootstrap" width="40" height="40">
    Bilang-Go</a>
    <div class="collapse navbar-collapse " id="navbarTogglerDemo03">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link text-black" aria-current="page" href="ahome.php">Dashboard</a>
        </li>
        <hr>
        <li class="nav-item">
          <a class="nav-link text-black " href="a_pb_home.php">Prison List</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-black" href="a_cb_home.php">Cell List</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-black" href="a_acc_home.php">Account List</a>
        </li>
        <hr>
        <li class="nav-item">
          <a class="nav-link text-black" href="a_in_home.php">Inmate List</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-black" href="a_vi_home.php">Visitor List</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-black " href="a_rep_home.php">Reports</a>
        </li>
      </ul>
      <hr>
       <a href=""> <button class="btn btn-dark text-white">Log-Out</button></a>
      
    </div>
  </div>
</nav>