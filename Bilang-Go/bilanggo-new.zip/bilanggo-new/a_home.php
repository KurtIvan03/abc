<?php include ('a_nav.php');
?><?php include ('database/data.php') ?>
    <div class="main">
        <div class="book-list-container">
            <div class="container-header row mb-3">
                <div class="col">
                    <h3>Prison List</h3>
                </div>
                <div class="col">
                    <button type="button" class="btn btn-secondary" id="addBook" data-toggle="modal" data-target="#addBookModal">Add Prison</button>
                </div>
            </div>
            <table class="table table-sm" id="borrowedTable">
                <thead>
                    <tr>
                    <th scope="col">Prison Name</th>
                    <th scope="col">Prison Status</th>
                    <th scope="col">Date Created</th>
                    <th scope="col" style="width: 60px;">Action</th>
                    </tr>
                </thead>
               
            </table>
        </div>
    </div>
<?php include ('a_footer.php'); ?>