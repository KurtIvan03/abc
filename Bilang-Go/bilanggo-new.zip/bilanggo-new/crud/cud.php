<?php
session_start();
include('data.php');









////////////////////////////////////////////////////////////////////////////////////
//crud for visitor

if(isset($_POST['save-visitor'])){

    $inmateid = $_POST['inmateid'];
    $relationship = $_POST['relationship'];
    $middlename = $_POST['middlename'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $contact = $_POST['contact'];
    $query = "INSERT INTO visitor
     (inmateid, relationship, middlename, firstname, lastname, contact, vi_date_create) 
    VALUES (:inmateid, :relationship, :middlename, :firstname, :lastname, :contact, CURRENT_TIMESTAMP)";
    $query_run = $pdo->prepare($query);

    $data = [
 
        ':contact' => $contact,
        ':lastname' => $lastname,
        ':firstname' => $firstname,
        ':middlename' => $middlename,
        ':relationship' => $relationship,
        ':inmateid' => $inmateid,
    ];
    $query_execute = $query_run->execute($data);
    if($query_execute){
        //$_SESSION['message'] = "Insert Successfully";
        header('Location:j_vi_home.php');
        exit(0);
    }else{
       // $_SESSION['message'] = "Not Insert ";
        header('Location:j_vi_home.php');
        exit(0);
    }
}



////////////////////////////////////////////////////////////////////////////////////
//crud for inmate
if(isset($_POST['delete-inmate'])){
    $inmate_id = $_POST['delete-inmate'];
    try {
        $query = "DELETE FROM inmate WHERE inmate_id=:id";
        $statement = $pdo->prepare($query);
        $data = [':id' => $inmate_id];
        $query_execute = $statement->execute($data);
        if($query_execute){
           // $_SESSION['message'] = "Delete Successfully";
            header('Location:o_in_home.php');
            exit(0);
        }else{
           // $_SESSION['message'] = "Not Delete ";
            header('Location:o_in_home.php');
            exit(0);
        }
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}

if(isset($_POST['update-in']))
{ 
    $lastname = $_POST['lastname'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $bday = $_POST['bday'];
    $gender = $_POST['gender'];
    $statuss = $_POST['statuss'];
    $street = $_POST['street'];
    $barangay = $_POST['barangay'];
    $municipality = $_POST['municipality'];
    $province = $_POST['province'];
    $country = $_POST['country'];
    $prison_code = $_POST['prison_code'];
    $cellname = $_POST['cellname'];
    $crime = $_POST['crime'];
    $sentence = $_POST['sentence'];
    $tds = $_POST['tds'];
    $tde = $_POST['tde'];
    $prisonname = $_POST['prisonname'];
    $inmate_id = $_POST['inmate_id'];
    
    try {
        $query = "UPDATE inmate SET 
        lastname=:lastname, firstname=:firstname, middlename=:middlename, bday=:bday,
        gender=:gender, statuss=:statuss, street=:street, barangay=:barangay,
        municipality=:municipality, province=:province, country=:country, prison_code=:prison_code,
        cellname=:cellname, crime=:crime, sentence=:sentence, tds=:tds, tde=:tde, prisonname=:prisonname WHERE inmate_id=:inmate_id LIMIT 1";
        $statement = $pdo->prepare($query);
        $data = [
            ':prisonname' => $prisonname,
            ':tde' => $tde,
            ':tds' => $tds,
            ':sentence' => $sentence,
            ':crime' => $crime,
            ':cellname' => $cellname,
            ':prison_code' => $prison_code,
            ':country' => $country,
            ':province' => $province,
            ':municipality' => $municipality,
            ':barangay' => $barangay,
            ':street' => $street,
            ':statuss' => $statuss,
            ':gender' => $gender,
            ':bday' => $bday,
            ':lastname' => $lastname,
            ':firstname' => $firstname,
            ':middlename' => $middlename,
            ':inmate_id' => $inmate_id
        ];
        $query_execute = $statement->execute($data);
        if($query_execute){
            //$_SESSION['message'] = "Update Successfully";
            header('Location:o_in_home.php');
            exit(0);
        }else{
           // $_SESSION['message'] = "Not Updated ";
            header('Location:o_in_home.php');
            exit(0);
        }
    } catch(PDOException $e) {
        echo $e->getMEssage();
    }
}
if(isset($_POST['save-inmate'])){

    $lastname = $_POST['lastname'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $bday = $_POST['bday'];
    $gender = $_POST['gender'];
    $statuss = $_POST['statuss'];
    $street = $_POST['street'];
    $barangay = $_POST['barangay'];
    $municipality = $_POST['municipality'];
    $province = $_POST['province'];
    $country = $_POST['country'];
    $prison_code = $_POST['prison_code'];
    $cellname = $_POST['cellname'];
    $crime = $_POST['crime'];
    $sentence = $_POST['sentence'];
    $tds = $_POST['tds'];
    $tde = $_POST['tde'];
    $prisonname = $_POST['prisonname'];
    $query = "INSERT INTO inmate
     (lastname, firstname, middlename, bday, gender, statuss, street,
      barangay, municipality, province, country, prison_code, cellname, crime, sentence, tds, tde,prisonname, date_create) 
    VALUES (:lastname, :firstname, :middlename, :bday, :gender, :statuss, :street, 
    :barangay, :municipality, :province, :country, :prison_code,:cellname, :crime, :sentence, :tds, :tde, :prisonname, CURRENT_TIMESTAMP)";
    $query_run = $pdo->prepare($query);

    $data = [
        
        ':tde' => $tde,
        ':prisonname' => $prisonname,
        ':tds' => $tds,
        ':sentence' => $sentence,
        ':crime' => $crime,
        ':cellname' => $cellname,
        ':prison_code' => $prison_code,
        ':country' => $country,
        ':province' => $province,
        ':municipality' => $municipality,
        ':barangay' => $barangay,
        ':street' => $street,
        ':statuss' => $statuss,
        ':gender' => $gender,
        ':bday' => $bday,
        ':middlename' => $middlename,
        ':firstname' => $firstname,
        ':lastname' => $lastname,
    ];
    $query_execute = $query_run->execute($data);
    if($query_execute){
        //$_SESSION['message'] = "Insert Successfully";
        header('Location:o_in_home.php');
        exit(0);
    }else{
       // $_SESSION['message'] = "Not Insert ";
        header('Location:o_in_home.php');
        exit(0);
    }
}


////////////////////////////////////////////////////////////////////////////////////
//crud for cell
if(isset($_POST['delete-cell'])){
    $cell_id = $_POST['delete-cell'];
    try {
        $query = "DELETE FROM cell WHERE cell_id=:id";
        $statement = $pdo->prepare($query);
        $data = [':id' => $cell_id];
        $query_execute = $statement->execute($data);
        if($query_execute){
           // $_SESSION['message'] = "Delete Successfully";
            header('Location:a_cb_home.php');
            exit(0);
        }else{
           // $_SESSION['message'] = "Not Delete ";
            header('Location:a_cb_home.php');
            exit(0);
        }
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}

if(isset($_POST['update-cell']))
{ 
    $cell_id = $_POST['cell_id'];
    $cell_name = $_POST['cell_name'];
    $cell_status = $_POST['cell_status'];
    $prisonid = $_POST['prisonid'];
    
    try {
        $query = "UPDATE cell SET 
        cell_name=:cell_name, cell_status=:cell_status, prisonid=:prisonid WHERE cell_id=:cell_id LIMIT 1";
        $statement = $pdo->prepare($query);
        $data = [
            ':cell_name' => $cell_name,
            ':cell_status' => $cell_status,
            ':prisonid' => $prisonid,
            ':cell_id' => $cell_id
        ];
        $query_execute = $statement->execute($data);
        if($query_execute){
            //$_SESSION['message'] = "Update Successfully";
            header('Location:a_cb_home.php');
            exit(0);
        }else{
           // $_SESSION['message'] = "Not Updated ";
            header('Location:a_cb_home.php');
            exit(0);
        }
    } catch(PDOException $e) {
        echo $e->getMEssage();
    }
}
if(isset($_POST['save-cell'])){

    $cell_name = $_POST['cell_name'];
    $prisonid = $_POST['prisonid'];
    $cell_status = $_POST['cell_status'];
    $query = "INSERT INTO cell
     (cell_name, prisonid, cell_status, cell_date_create) 
    VALUES (:cell_name, :prisonid, :cell_status, CURRENT_TIMESTAMP)";
    $query_run = $pdo->prepare($query);

    $data = [
        ':cell_name' => $cell_name,
        ':prisonid' => $prisonid,
        ':cell_status' => $cell_status,
    ];
    $query_execute = $query_run->execute($data);
    if($query_execute){
        //$_SESSION['message'] = "Insert Successfully";
        header('Location:a_cb_home.php');
        exit(0);
    }else{
       // $_SESSION['message'] = "Not Insert ";
        header('Location:a_cb_home.php');
        exit(0);
    }
}


////////////////////////////////////////////////////////////////////////////////////
//crud for jailer
if(isset($_POST['delete-jailer'])){
    $id = $_POST['delete-jailer'];
    try {
        $query = "DELETE FROM jailer WHERE id=:id";
        $statement = $pdo->prepare($query);
        $data = [':id' => $id];
        $query_execute = $statement->execute($data);
        if($query_execute){
           // $_SESSION['message'] = "Delete Successfully";
            header('Location:a_acc_home.php');
            exit(0);
        }else{
           // $_SESSION['message'] = "Not Delete ";
            header('Location:a_acc_home.php');
            exit(0);
        }
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}

if(isset($_POST['update-jailer']))
{ 
    $id = $_POST['id'];
    $uname = $_POST['uname'];
    $pword = $_POST['pword'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    try {
        $query = "UPDATE jailer SET 
        uname=:uname, pword=:pword, firstname=:firstname, middlename=:middlename, lastname=:lastname, email=:email
         WHERE id=:id LIMIT 1";
        $statement = $pdo->prepare($query);
        $data = [
            ':uname' => $uname,
            ':pword' => $pword,
            ':firstname' => $firstname,
            ':middlename' => $middlename,
            ':lastname' => $lastname,
            ':email' => $email,
            ':id' => $id
        ];
        $query_execute = $statement->execute($data);
        if($query_execute){
            //$_SESSION['message'] = "Update Successfully";
            header('Location:a_acc_home.php');
            exit(0);
        }else{
           // $_SESSION['message'] = "Not Updated ";
            header('Location:a_acc_home.php');
            exit(0);
        }
    } catch(PDOException $e) {
        echo $e->getMEssage();
    }
}
if(isset($_POST['save-jailer'])){

    $uname = $_POST['uname'];
    $pword = $_POST['pword'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $query = "INSERT INTO jailer
     (uname, pword, firstname, middlename, lastname, email, date_create) 
    VALUES (:uname, :pword, :firstname, :middlename, :lastname, :email, CURRENT_TIMESTAMP)";
    $query_run = $pdo->prepare($query);

    $data = [
        ':uname' => $uname,
        ':pword' => $pword,
        ':firstname' => $firstname,
        ':middlename' => $middlename,
        ':lastname' => $lastname,
        ':email' => $email
    ];
    $query_execute = $query_run->execute($data);
    if($query_execute){
        //$_SESSION['message'] = "Insert Successfully";
        header('Location:a_acc_home.php');
        exit(0);
    }else{
       // $_SESSION['message'] = "Not Insert ";
        header('Location:a_acc_home.php');
        exit(0);
    }
}


////////////////////////////////////////////////////////////////////////////////////
//crud for officer
if(isset($_POST['delete-officer'])){
    $id = $_POST['delete-officer'];
    try {
        $query = "DELETE FROM officer WHERE id=:id";
        $statement = $pdo->prepare($query);
        $data = [':id' => $id];
        $query_execute = $statement->execute($data);
        if($query_execute){
           // $_SESSION['message'] = "Delete Successfully";
            header('Location:a_acc_home.php');
            exit(0);
        }else{
           // $_SESSION['message'] = "Not Delete ";
            header('Location:a_acc_home.php');
            exit(0);
        }
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}

if(isset($_POST['update-officer']))
{ 
    $id = $_POST['id'];
    $uname = $_POST['uname'];
    $pword = $_POST['pword'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    try {
        $query = "UPDATE officer SET 
        uname=:uname, pword=:pword, firstname=:firstname, middlename=:middlename, lastname=:lastname, email=:email
         WHERE id=:id LIMIT 1";
        $statement = $pdo->prepare($query);
        $data = [
            ':uname' => $uname,
            ':pword' => $pword,
            ':firstname' => $firstname,
            ':middlename' => $middlename,
            ':lastname' => $lastname,
            ':email' => $email,
            ':id' => $id
        ];
        $query_execute = $statement->execute($data);
        if($query_execute){
            //$_SESSION['message'] = "Update Successfully";
            header('Location:a_acc_home.php');
            exit(0);
        }else{
           // $_SESSION['message'] = "Not Updated ";
            header('Location:a_acc_home.php');
            exit(0);
        }
    } catch(PDOException $e) {
        echo $e->getMEssage();
    }
}
if(isset($_POST['save-officer'])){

    $uname = $_POST['uname'];
    $pword = $_POST['pword'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $query = "INSERT INTO officer
     (uname, pword, firstname, middlename, lastname, email, date_create) 
    VALUES (:uname, :pword, :firstname, :middlename, :lastname, :email, CURRENT_TIMESTAMP)";
    $query_run = $pdo->prepare($query);

    $data = [
        ':uname' => $uname,
        ':pword' => $pword,
        ':firstname' => $firstname,
        ':middlename' => $middlename,
        ':lastname' => $lastname,
        ':email' => $email
    ];
    $query_execute = $query_run->execute($data);
    if($query_execute){
        //$_SESSION['message'] = "Insert Successfully";
        header('Location:a_acc_home.php');
        exit(0);
    }else{
       // $_SESSION['message'] = "Not Insert ";
        header('Location:a_acc_home.php');
        exit(0);
    }
}


////////////////////////////////////////////////////////////////////////////////////
//crud for admin
if(isset($_POST['delete-admin'])){
    $id = $_POST['delete-admin'];
    try {
        $query = "DELETE FROM admin WHERE id=:id";
        $statement = $pdo->prepare($query);
        $data = [':id' => $id];
        $query_execute = $statement->execute($data);
        if($query_execute){
           // $_SESSION['message'] = "Delete Successfully";
            header('Location:a_acc_home.php');
            exit(0);
        }else{
           // $_SESSION['message'] = "Not Delete ";
            header('Location:a_acc_home.php');
            exit(0);
        }
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}

if(isset($_POST['update-admin']))
{ 
    $id = $_POST['id'];
    $uname = $_POST['uname'];
    $pword = $_POST['pword'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    try {
        $query = "UPDATE admin SET 
        uname=:uname, pword=:pword, firstname=:firstname, middlename=:middlename, lastname=:lastname, email=:email
         WHERE id=:id LIMIT 1";
        $statement = $pdo->prepare($query);
        $data = [
            ':uname' => $uname,
            ':pword' => $pword,
            ':firstname' => $firstname,
            ':middlename' => $middlename,
            ':lastname' => $lastname,
            ':email' => $email,
            ':id' => $id
        ];
        $query_execute = $statement->execute($data);
        if($query_execute){
            //$_SESSION['message'] = "Update Successfully";
            header('Location:a_acc_home.php');
            exit(0);
        }else{
           // $_SESSION['message'] = "Not Updated ";
            header('Location:a_acc_home.php');
            exit(0);
        }
    } catch(PDOException $e) {
        echo $e->getMEssage();
    }
}
if(isset($_POST['save-admin'])){
    $pword = $_POST['pword'];
    $uname = $_POST['uname'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $query = "INSERT INTO admin
     (uname, pword, firstname, middlename, lastname, email, date_create) 
    VALUES (:uname, :pword, :firstname, :middlename, :lastname, :email, CURRENT_TIMESTAMP)";
    $query_run = $pdo->prepare($query);

    $data = [
        ':uname' => $uname,
        ':pword' => $pword,
        ':firstname' => $firstname,
        ':middlename' => $middlename,
        ':lastname' => $lastname,
        ':email' => $email
    ];
    $query_execute = $query_run->execute($data);
    if($query_execute){
        //$_SESSION['message'] = "Insert Successfully";
        header('Location:a_acc_home.php');
        exit(0);
    }else{
       // $_SESSION['message'] = "Not Insert ";
        header('Location:a_acc_home.php');
        exit(0);
    }
}



////////////////////////////////////////////////////////////////////////////////////
//create, delete and update about prison block
if(isset($_POST['delete-prison'])){
    $prison_id = $_POST['delete-prison'];
    try {
        $query = "DELETE FROM prison WHERE prison_id=:id";
        $statement = $pdo->prepare($query);
        $data = [':id' => $prison_id];
        $query_execute = $statement->execute($data);
        if($query_execute){
           // $_SESSION['message'] = "Delete Successfully";
            header('Location:a_pb_home.php');
            exit(0);
        }else{
           // $_SESSION['message'] = "Not Delete ";
            header('Location:a_pb_home.php');
            exit(0);
        }
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}
if(isset($_POST['update-prison']))
{
    $prison_id = $_POST['prison_id'];
    $prison_name = $_POST['prison_name'];
    $prison_status = $_POST['prison_status'];
    try {
        $query = "UPDATE  prison SET prison_name=:prison_name, prison_status=:prison_status WHERE prison_id=:prison_id LIMIT 1";
        $statement = $pdo->prepare($query);
        $data = [
            ':prison_name' => $prison_name,
            ':prison_status' => $prison_status,
            ':prison_id' => $prison_id
        ];
        $query_execute = $statement->execute($data);
        if($query_execute){
            //$_SESSION['message'] = "Update Successfully";
            header('Location:a_pb_home.php');
            exit(0);
        }else{
           // $_SESSION['message'] = "Not Updated ";
            header('Location:a_pb_home.php');
            exit(0);
        }
    } catch(PDOException $e) {
        echo $e->getMEssage();
    }
}
if(isset($_POST['save-prison'])){

    $prison_name = $_POST['prison_name'];
    $prison_status = $_POST['prison_status'];
    $query = "INSERT INTO prison (prison_name, prison_status, date_create) VALUES (:prison_name, :prison_status, CURRENT_TIMESTAMP)";
    $query_run = $pdo->prepare($query);

    $data = [
        ':prison_name' => $prison_name,
        ':prison_status' => $prison_status
    ];
    $query_execute = $query_run->execute($data);
    if($query_execute){
        //$_SESSION['message'] = "Insert Successfully";
        header('Location:a_pb_home.php');
        exit(0);
    }else{
       // $_SESSION['message'] = "Not Insert ";
        header('Location:a_pb_home.php');
        exit(0);
    }
}

?>